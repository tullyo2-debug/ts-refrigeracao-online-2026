# TS Refrigeração — versão corrigida para Vercel

Esta versão usa JavaScript + Vite para evitar o erro de build TypeScript da versão anterior.

## Vercel
- Framework: Vite
- Build command: `npm run build`
- Output directory: `dist`

## Variáveis
`VITE_SUPABASE_URL`
`VITE_SUPABASE_PUBLISHABLE_KEY`

Nunca coloque `sb_secret_...` no frontend.

O projeto espera as tabelas Supabase já criadas no banco.

## Gerar APK (Android) com Capacitor
Requisitos: Node 18+, Android Studio (com SDK) e JDK 17.

1. `cp .env.example .env` e preencha as chaves do Supabase (elas são embutidas no build).
2. `npm install`
3. `npm run build`
4. `npx cap add android`  (só na primeira vez)
5. `npm run android:sync`
6. `npm run android:open` → no Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
   Ou, pelo terminal: `cd android && ./gradlew assembleDebug`
   O arquivo sai em `android/app/build/outputs/apk/debug/app-debug.apk`.

Para publicar na Play Store, gere um APK/AAB assinado (Build > Generate Signed Bundle / APK).
Em Supabase > Authentication > URL Configuration, não é necessário liberar domínio para login por e-mail/senha.
