import { createClient } from '@supabase/supabase-js'
const url = import.meta.env.VITE_SUPABASE_URL, key = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY
export const sb = url && key ? createClient(url, key) : null
export const $ = (s, r = document) => r.querySelector(s)
export const $$ = (s, r = document) => [...r.querySelectorAll(s)]
export const state = { me: null, go: () => {} }
export const esc = v => String(v ?? '').replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[m]))
export const money = v => Number(v || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
export const dt = v => (v ? String(v).slice(0, 10).split('-').reverse().join('/') : '')
export const debounce = (f, ms = 250) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => f(...a), ms) } }
export function toast(msg, err) {
  const t = document.createElement('div')
  t.className = 'toast' + (err ? ' err' : ''); t.textContent = msg; t.setAttribute('role', 'status')
  document.body.append(t); setTimeout(() => t.remove(), 3500)
}
export async function busy(btn, fn) {
  const o = btn.textContent; btn.disabled = true; btn.textContent = 'Salvando...'
  try { await fn() } catch (e) { toast(e.message, 1) } finally { btn.disabled = false; btn.textContent = o }
}
const dig = v => String(v || '').replace(/\D/g, '')
export const mask = {
  tel: v => { v = dig(v).slice(0, 11); return v.length > 10 ? v.replace(/(\d\d)(\d{5})(\d{4})/, '($1) $2-$3') : v.replace(/(\d\d)(\d{4})(\d{0,4})/, '($1) $2-$3').replace(/-$/, '') },
  doc: v => { v = dig(v).slice(0, 14); return v.length > 11 ? v.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{0,2})/, '$1.$2.$3/$4-$5') : v.replace(/(\d{3})(\d{3})(\d{3})(\d{0,2})/, '$1.$2.$3-$4') },
  cep: v => dig(v).slice(0, 8).replace(/(\d{5})(\d{0,3})/, '$1-$2').replace(/-$/, ''),
}
export function validDoc(v) {
  v = dig(v); if (!v) return true
  if (v.length !== 11 && v.length !== 14) return false
  if (/^(\d)\1+$/.test(v)) return false
  const calc = (n, w) => { let s = 0; for (let i = 0; i < n; i++) s += +v[i] * w[i]; const r = s % 11; return r < 2 ? 0 : 11 - r }
  if (v.length === 11) return calc(9, [10, 9, 8, 7, 6, 5, 4, 3, 2]) === +v[9] && calc(10, [11, 10, 9, 8, 7, 6, 5, 4, 3, 2]) === +v[10]
  return calc(12, [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]) === +v[12] && calc(13, [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]) === +v[13]
}
