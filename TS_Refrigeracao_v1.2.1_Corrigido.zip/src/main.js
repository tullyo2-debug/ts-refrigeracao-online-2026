import './style.css'
import { sb, $, $$, esc, state } from './lib.js'
import * as P from './pages.js'
const app = $('#app')
if (!sb) {
  app.innerHTML = '<main class="setup"><h1>TS Refrigeração</h1><p>Configure <code>.env</code> com VITE_SUPABASE_URL e VITE_SUPABASE_PUBLISHABLE_KEY.</p></main>'
  throw new Error('Variáveis do Supabase ausentes')
}
const pages = { dashboard: ['Dashboard', P.dashboard], clientes: ['Clientes', P.clientes], agenda: ['Agenda', P.agenda], os: ['Ordens de serviço', P.ordens], financeiro: ['Financeiro', P.financeiro], servicos: ['Serviços', P.servicos], usuarios: ['Usuários', P.usuarios] }
const menu = [['dashboard', '📊 Dashboard'], ['clientes', '👥 Clientes'], ['agenda', '📅 Agenda'], ['os', '🧾 Ordens de serviço'], ['financeiro', '💰 Financeiro'], ['servicos', '🛠️ Serviços'], ['usuarios', '👤 Usuários']]
let seq = 0
async function getMe(user) {
  const { data, error } = await sb.from('usuarios').select('id,nome,perfil_id,ativo,perfis(id,nome,descricao)').eq('id', user.id).maybeSingle()
  if (error) throw error
  return data && { ...data, perfil: Array.isArray(data.perfis) ? data.perfis[0] : data.perfis }
}
async function go(page) {
  const [title, fn] = pages[page] || pages.dashboard, id = ++seq
  $$('[data-page]').forEach(b => b.classList.toggle('active', b.dataset.page === page))
  $('#page-title').textContent = title; $('.sidebar').classList.remove('open')
  const c = $('#content'); c.innerHTML = '<div class="loading">Carregando...</div>'
  const el = document.createElement('div')
  try { await fn(el) } catch (e) { el.innerHTML = `<div class="error"><b>Erro:</b> ${esc(e.message)}</div>` }
  if (id === seq) c.replaceChildren(...el.childNodes) // evita resposta lenta sobrescrever página atual
}
state.go = go
function shell(me) {
  const admin = /admin/i.test(me.perfil?.nome || '')
  app.innerHTML = `<div class="layout"><aside class="sidebar"><div class="brand"><div class="brand-mark">TS</div><div><strong>TS Refrigeração</strong><small>Sistema Online</small></div></div>
  <nav>${menu.filter(([p]) => p !== 'usuarios' || admin).map(([p, l]) => `<button data-page="${p}">${l}</button>`).join('')}</nav>
  <div class="userbox"><b>${esc(me.nome)}</b><span>${esc(me.perfil?.nome)}</span><button id="logout">Sair</button></div></aside>
  <section class="main"><header><div><h2 id="page-title"></h2><span id="status"></span></div><button class="mobile-menu" id="mobileMenu" aria-label="Menu">☰</button></header><div id="content"></div></section></div>`
  $$('[data-page]').forEach(b => b.addEventListener('click', () => go(b.dataset.page)))
  $('#logout').addEventListener('click', () => sb.auth.signOut())
  $('#mobileMenu').addEventListener('click', () => $('.sidebar').classList.toggle('open'))
  const st = () => { $('#status').textContent = navigator.onLine ? 'Online' : 'Sem conexão' }
  st(); addEventListener('online', st); addEventListener('offline', st)
}
function login(msg = '') {
  app.innerHTML = `<main class="login"><form class="login-card" id="lf"><div class="brand center"><div class="brand-mark">TS</div><div><strong>TS Refrigeração</strong><small>Gestão de serviços</small></div></div><h1>Acesso ao sistema</h1>${msg ? `<div class="error">${esc(msg)}</div>` : ''}<label>E-mail<input id="email" type="email" autocomplete="username" required></label><label>Senha<input id="password" type="password" autocomplete="current-password" required></label><button class="primary full" id="lb">Entrar</button></form></main>`
  $('#lf').addEventListener('submit', async e => {
    e.preventDefault(); $('#lb').disabled = true
    const { error } = await sb.auth.signInWithPassword({ email: $('#email').value, password: $('#password').value })
    if (error) return login(error.message)
    boot()
  })
}
async function boot() {
  const { data: { session } } = await sb.auth.getSession()
  if (!session) return login()
  const me = await getMe(session.user).catch(e => { login(e.message) })
  if (me === undefined) return
  if (!me) return login('Seu usuário Auth ainda não está associado à tabela usuarios.')
  if (!me.ativo) return login('Seu usuário está inativo.')
  state.me = me; shell(me); go('dashboard')
}
sb.auth.onAuthStateChange((ev, s) => { if (ev === 'SIGNED_OUT' || !s) login() })
boot()
if ('serviceWorker' in navigator) addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}))
