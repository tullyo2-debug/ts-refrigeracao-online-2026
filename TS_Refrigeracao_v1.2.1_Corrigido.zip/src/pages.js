import { sb, $, $$, esc, money, dt, debounce, toast, busy, mask, validDoc, state } from './lib.js'
const go = p => state.go(p)
const view = h => { $('#content').innerHTML = h }
const table = (rows, heads, empty = 'Nada por aqui ainda.') => `<div class="table-wrap"><table><thead><tr>${heads.map(h => `<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.join('') || `<tr><td colspan="${heads.length}" class="loading">${empty}</td></tr>`}</tbody></table></div>`
const opts = (list, sel, lbl = 'nome') => list.map(x => `<option value="${esc(x.id)}" ${x.id === sel ? 'selected' : ''}>${esc(x[lbl])}</option>`).join('')
const must = ({ error, data }) => { if (error) throw error; return data }
const STATUS = ['aberta', 'em_andamento', 'concluida', 'cancelada']
const val = id => $('#' + id).value.trim()

export async function dashboard(c) {
  const [cli, ag, os, pay] = await Promise.all([
    sb.from('clientes').select('id', { count: 'exact', head: true }).eq('ativo', true),
    sb.from('agendamentos').select('id', { count: 'exact', head: true }).eq('status', 'agendado'),
    sb.from('ordens_servico').select('valor_total,status').limit(5000),
    sb.from('pagamentos').select('valor').limit(5000)])
  const o = must(os), validas = o.filter(r => r.status !== 'cancelada')
  const abertas = o.filter(r => ['aberta', 'em_andamento'].includes(r.status)).length
  const total = validas.reduce((s, r) => s + Number(r.valor_total || 0), 0), rec = must(pay).reduce((s, r) => s + Number(r.valor || 0), 0)
  const hoje = new Date().toISOString().slice(0, 10)
  const hj = must(await sb.from('agendamentos').select('hora_inicio,tipo_servico,clientes(nome)').eq('data_agendamento', hoje).order('hora_inicio'))
  c.innerHTML = `<div class="hero"><div><h1>Olá! 👋</h1><p>Gestão da TS Refrigeração em um só lugar.</p></div><button class="primary" id="n">+ Nova OS</button></div>
  <div class="cards">${[['Clientes', cli.count || 0], ['OS abertas', abertas], ['Agendados', ag.count || 0], ['Total das OS', money(total)], ['A receber', money(total - rec)]].map(([a, b]) => `<div class="card"><span>${a}</span><b>${b}</b></div>`).join('')}</div>
  <div class="panel"><h3>Agenda de hoje</h3>${table(hj.map(x => `<tr><td>${esc(x.hora_inicio?.slice(0, 5))}</td><td>${esc(x.clientes?.nome)}</td><td>${esc(x.tipo_servico)}</td></tr>`), ['Hora', 'Cliente', 'Serviço'], 'Nenhum atendimento hoje.')}</div>`
  $('#n', c).addEventListener('click', () => osForm())
}

export async function clientes(c) {
  const data = must(await sb.from('clientes').select('*').eq('ativo', true).order('nome').limit(1000))
  c.innerHTML = '<div class="toolbar"><input id="q" placeholder="Buscar cliente..."><button class="primary" id="add">+ Novo cliente</button></div><div id="t"></div>'
  const render = (f = '') => {
    const l = data.filter(x => `${x.nome} ${x.telefone || ''} ${x.cpf_cnpj || ''}`.toLowerCase().includes(f.toLowerCase()))
    $('#t', c).innerHTML = table(l.map(x => `<tr><td><b>${esc(x.nome)}</b><small>${esc(x.cpf_cnpj)}</small></td><td>${esc(x.telefone || x.whatsapp)}</td><td>${esc(x.cidade)}${x.estado ? '/' + esc(x.estado) : ''}</td><td><button class="link" data-id="${esc(x.id)}">Editar</button></td></tr>`), ['Cliente', 'Telefone', 'Local', ''], 'Nenhum cliente encontrado.')
    $$('[data-id]', c).forEach(b => b.addEventListener('click', () => clientForm(data.find(x => x.id === b.dataset.id))))
  }
  render(); $('#q', c).addEventListener('input', debounce(e => render(e.target.value))); $('#add', c).addEventListener('click', () => clientForm())
}
function clientForm(x = {}) {
  const f = [['nome', 'Nome*'], ['cpf_cnpj', 'CPF/CNPJ'], ['telefone', 'Telefone'], ['whatsapp', 'WhatsApp'], ['email', 'E-mail'], ['cep', 'CEP'], ['endereco', 'Endereço'], ['numero', 'Número'], ['complemento', 'Complemento'], ['bairro', 'Bairro'], ['cidade', 'Cidade'], ['estado', 'UF']]
  view(`<div class="panel form"><h3>${x.id ? 'Editar' : 'Novo'} cliente</h3><div class="grid2"><label>Tipo<select id="tipo_pessoa"><option ${x.tipo_pessoa !== 'PJ' ? 'selected' : ''}>PF</option><option ${x.tipo_pessoa === 'PJ' ? 'selected' : ''}>PJ</option></select></label>
  ${f.map(([k, l]) => `<label>${l}<input id="${k}" value="${esc(x[k])}" ${k === 'estado' ? 'maxlength="2"' : ''}></label>`).join('')}</div>
  <div class="actions">${x.id ? '<button class="secondary" id="del">Inativar</button>' : ''}<button class="secondary" id="cancel">Cancelar</button><button class="primary" id="save">Salvar cliente</button></div></div>`)
  for (const [id, m] of [['telefone', 'tel'], ['whatsapp', 'tel'], ['cpf_cnpj', 'doc'], ['cep', 'cep']]) $('#' + id).addEventListener('input', e => { e.target.value = mask[m](e.target.value) })
  $('#cep').addEventListener('blur', async () => {
    const v = val('cep').replace(/\D/g, ''); if (v.length !== 8) return
    try { const r = await (await fetch(`https://viacep.com.br/ws/${v}/json/`)).json(); if (!r.erro) { $('#endereco').value = r.logradouro; $('#bairro').value = r.bairro; $('#cidade').value = r.localidade; $('#estado').value = r.uf } } catch {}
  })
  $('#cancel').addEventListener('click', () => go('clientes'))
  $('#del')?.addEventListener('click', e => confirm('Inativar este cliente?') && busy(e.target, async () => { must(await sb.from('clientes').update({ ativo: false }).eq('id', x.id)); toast('Cliente inativado.'); go('clientes') }))
  $('#save').addEventListener('click', e => {
    if (!val('nome')) return toast('Informe o nome.', 1)
    if (!validDoc(val('cpf_cnpj'))) return toast('CPF/CNPJ inválido.', 1)
    if (val('email') && !/^\S+@\S+\.\S+$/.test(val('email'))) return toast('E-mail inválido.', 1)
    busy(e.target, async () => {
      const p = Object.fromEntries([...f.map(([k]) => [k, val(k)]), ['tipo_pessoa', val('tipo_pessoa')]]); p.estado = p.estado.toUpperCase(); p.ativo = true
      const { data: { user } } = await sb.auth.getUser()
      must(x.id ? await sb.from('clientes').update(p).eq('id', x.id) : await sb.from('clientes').insert({ ...p, criado_por: user.id }))
      toast('Cliente salvo.'); go('clientes')
    })
  })
}

export async function agenda(c) {
  c.innerHTML = '<div class="toolbar"><input id="date" type="date"><button class="secondary" id="all">Todas</button><button class="primary" id="add">+ Agendar</button></div><div id="t"></div>'
  const load = async () => {
    let q = sb.from('agendamentos').select('*,clientes(nome),usuarios(nome)').order('data_agendamento').order('hora_inicio').limit(300)
    if ($('#date', c).value) q = q.eq('data_agendamento', $('#date', c).value)
    const d = must(await q)
    $('#t', c).innerHTML = table(d.map(x => `<tr><td>${dt(x.data_agendamento)} ${esc(x.hora_inicio?.slice(0, 5))}</td><td>${esc(x.clientes?.nome)}<small>${esc(x.usuarios?.nome)}</small></td><td>${esc(x.tipo_servico)}</td><td><select data-st="${esc(x.id)}">${['agendado', 'concluido', 'cancelado'].map(s => `<option ${s === x.status ? 'selected' : ''}>${s}</option>`).join('')}</select></td></tr>`), ['Data/Hora', 'Cliente / Técnico', 'Serviço', 'Status'], 'Nenhum agendamento.')
    $$('[data-st]', c).forEach(s => s.addEventListener('change', async () => { must(await sb.from('agendamentos').update({ status: s.value }).eq('id', s.dataset.st)); toast('Status atualizado.') }))
  }
  $('#date', c).addEventListener('change', () => load().catch(e => toast(e.message, 1)))
  $('#all', c).addEventListener('click', () => { $('#date', c).value = ''; load() })
  $('#add', c).addEventListener('click', agendaForm); await load()
}
async function agendaForm() {
  const [cl, te] = await Promise.all([sb.from('clientes').select('id,nome').eq('ativo', true).order('nome'), sb.from('usuarios').select('id,nome').eq('ativo', true).order('nome')])
  view(`<div class="panel form"><h3>Novo agendamento</h3><div class="grid2"><label>Cliente*<select id="cli"><option value="">Selecione</option>${opts(must(cl))}</select></label><label>Técnico<select id="tec"><option value="">Selecione</option>${opts(must(te))}</select></label>
  <label>Data*<input id="d" type="date"></label><label>Hora*<input id="h" type="time"></label><label class="wide">Tipo de serviço<input id="ts"></label></div>
  <div class="actions"><button class="secondary" id="cancel">Cancelar</button><button class="primary" id="save">Agendar</button></div></div>`)
  $('#cancel').addEventListener('click', () => go('agenda'))
  $('#save').addEventListener('click', e => {
    if (!val('cli') || !val('d') || !val('h')) return toast('Preencha cliente, data e hora.', 1)
    busy(e.target, async () => { must(await sb.from('agendamentos').insert({ cliente_id: val('cli'), tecnico_id: val('tec') || null, data_agendamento: val('d'), hora_inicio: val('h'), tipo_servico: val('ts'), status: 'agendado' })); toast('Agendado.'); go('agenda') })
  })
}

export async function ordens(c) {
  const data = must(await sb.from('ordens_servico').select('*,clientes(nome,whatsapp,telefone)').order('criado_em', { ascending: false }).limit(300))
  c.innerHTML = `<div class="toolbar"><input id="q" placeholder="Buscar número, cliente..."><select id="st" style="max-width:170px"><option value="">Todos</option>${STATUS.map(s => `<option>${s}</option>`).join('')}</select><button class="primary" id="add">+ Nova OS</button></div><div id="t"></div>`
  const render = () => {
    const f = $('#q', c).value.toLowerCase(), s = $('#st', c).value
    const l = data.filter(x => (!s || x.status === s) && `${x.numero} ${x.clientes?.nome || ''}`.toLowerCase().includes(f))
    $('#t', c).innerHTML = table(l.map(x => `<tr><td><b>#${esc(x.numero)}</b></td><td>${esc(x.clientes?.nome)}</td><td><span class="badge">${esc(x.status)}</span></td><td>${money(x.valor_total)}</td><td><button class="link" data-os="${esc(x.id)}">Abrir</button></td></tr>`), ['OS', 'Cliente', 'Status', 'Total', ''], 'Nenhuma OS encontrada.')
    $$('[data-os]', c).forEach(b => b.addEventListener('click', () => osView(data.find(x => x.id === b.dataset.os))))
  }
  render(); $('#q', c).addEventListener('input', debounce(render)); $('#st', c).addEventListener('change', render); $('#add', c).addEventListener('click', () => osForm())
}
async function osForm() {
  const [cl, te, sv] = (await Promise.all([sb.from('clientes').select('id,nome').eq('ativo', true).order('nome'), sb.from('usuarios').select('id,nome').eq('ativo', true).order('nome'), sb.from('servicos').select('id,nome,valor_padrao').eq('ativo', true).order('nome')])).map(must)
  view(`<div class="panel form"><h3>Nova ordem de serviço</h3><div class="grid2"><label>Cliente*<select id="cli"><option value="">Selecione</option>${opts(cl)}</select></label><label>Técnico<select id="tec"><option value="">Selecione</option>${opts(te)}</select></label>
  <label>Serviço (preenche o valor)<select id="svc"><option value="">—</option>${sv.map(s => `<option value="${esc(s.valor_padrao)}">${esc(s.nome)}</option>`).join('')}</select></label><label>Prioridade<select id="prioridade"><option>normal</option><option>alta</option><option>urgente</option></select></label>
  <label>Valor dos serviços<input id="vs" type="number" step="0.01" min="0" value="0"></label><label>Valor das peças<input id="vp" type="number" step="0.01" min="0" value="0"></label><label>Desconto<input id="dc" type="number" step="0.01" min="0" value="0"></label><label>Total<input id="tot" readonly></label>
  ${[['problema_relatado', 'Problema relatado'], ['diagnostico', 'Diagnóstico'], ['servico_executado', 'Serviço executado'], ['observacoes', 'Observações']].map(([k, l]) => `<label class="wide">${l}<textarea id="${k}"></textarea></label>`).join('')}</div>
  <div class="actions"><button class="secondary" id="back">Cancelar</button><button class="primary" id="save">Criar OS</button></div></div>`)
  const calc = () => { $('#tot').value = money(Math.max(0, +$('#vs').value + +$('#vp').value - +$('#dc').value)) }
  $('#svc').addEventListener('change', e => { if (e.target.value) $('#vs').value = e.target.value; calc() }); ['vs', 'vp', 'dc'].forEach(i => $('#' + i).addEventListener('input', calc)); calc()
  $('#back').addEventListener('click', () => go('os'))
  $('#save').addEventListener('click', e => {
    if (!val('cli')) return toast('Selecione o cliente.', 1)
    busy(e.target, async () => {
      const { data: { user } } = await sb.auth.getUser(), vs = +val('vs'), vp = +val('vp'), dc = +val('dc')
      const d = must(await sb.from('ordens_servico').insert({ cliente_id: val('cli'), tecnico_id: val('tec') || null, status: 'aberta', prioridade: val('prioridade'), ...Object.fromEntries(['problema_relatado', 'diagnostico', 'servico_executado', 'observacoes'].map(k => [k, val(k)])), valor_servicos: vs, valor_pecas: vp, desconto: dc, valor_total: Math.max(0, vs + vp - dc), criado_por: user.id }).select().single())
      toast(`OS #${d.numero} criada.`); go('os')
    })
  })
}
async function osView(x) {
  const pays = must(await sb.from('pagamentos').select('valor,forma_pagamento,data_pagamento').eq('ordem_servico_id', x.id).order('data_pagamento'))
  const pago = pays.reduce((s, p) => s + Number(p.valor), 0), fone = (x.clientes?.whatsapp || x.clientes?.telefone || '').replace(/\D/g, '')
  const msg = encodeURIComponent(`Olá, ${x.clientes?.nome}! OS #${x.numero} da TS Refrigeração. Total: ${money(x.valor_total)}. Status: ${x.status}.`)
  view(`<div class="panel"><div class="detail-head"><div><h3>OS #${esc(x.numero)}</h3><p>${esc(x.clientes?.nome)}</p></div><select id="st">${STATUS.map(s => `<option ${s === x.status ? 'selected' : ''}>${s}</option>`).join('')}</select></div>
  <div class="cards mini">${[['Serviços', x.valor_servicos], ['Peças', x.valor_pecas], ['Desconto', x.desconto], ['Total', x.valor_total]].map(([a, b]) => `<div class="card"><span>${a}</span><b>${money(b)}</b></div>`).join('')}</div>
  <dl class="details"><dt>Prioridade</dt><dd>${esc(x.prioridade)}</dd><dt>Problema</dt><dd>${esc(x.problema_relatado)}</dd><dt>Diagnóstico</dt><dd>${esc(x.diagnostico)}</dd><dt>Serviço executado</dt><dd>${esc(x.servico_executado)}</dd><dt>Observações</dt><dd>${esc(x.observacoes)}</dd></dl>
  <h3>Pagamentos (${money(pago)} de ${money(x.valor_total)})</h3>${table(pays.map(p => `<tr><td>${dt(p.data_pagamento)}</td><td>${esc(p.forma_pagamento)}</td><td>${money(p.valor)}</td></tr>`), ['Data', 'Forma', 'Valor'], 'Nenhum pagamento.')}
  <div class="toolbar" style="margin-top:12px"><input id="pv" type="number" step="0.01" min="0.01" placeholder="Valor" value="${Math.max(0, x.valor_total - pago).toFixed(2)}"><select id="pf">${['pix', 'dinheiro', 'cartao', 'transferencia'].map(f => `<option>${f}</option>`).join('')}</select><button class="primary" id="pay">Registrar pagamento</button></div>
  <div class="actions"><button class="secondary" id="back">Voltar</button><button class="secondary" onclick="print()">Imprimir</button>${fone ? `<a class="secondary" style="text-decoration:none" target="_blank" rel="noopener" href="https://wa.me/55${fone}?text=${msg}">WhatsApp</a>` : ''}</div></div>`)
  $('#back').addEventListener('click', () => go('os'))
  $('#st').addEventListener('change', async e => { must(await sb.from('ordens_servico').update({ status: e.target.value }).eq('id', x.id)); x.status = e.target.value; toast('Status atualizado.') })
  $('#pay').addEventListener('click', e => { if (!(+val('pv') > 0)) return toast('Valor inválido.', 1); busy(e.target, async () => { must(await sb.from('pagamentos').insert({ ordem_servico_id: x.id, valor: +val('pv'), forma_pagamento: val('pf'), data_pagamento: new Date().toISOString() })); toast('Pagamento registrado.'); osView(x) }) })
}

export async function financeiro(c) {
  const d = must(await sb.from('pagamentos').select('*,ordens_servico(numero,clientes(nome))').order('data_pagamento', { ascending: false }).limit(200))
  const mes = new Date().toISOString().slice(0, 7), t = d.reduce((s, x) => s + Number(x.valor || 0), 0), m = d.filter(x => String(x.data_pagamento).startsWith(mes)).reduce((s, x) => s + Number(x.valor || 0), 0)
  c.innerHTML = `<div class="cards"><div class="card"><span>Recebido (carregado)</span><b>${money(t)}</b></div><div class="card"><span>Neste mês</span><b>${money(m)}</b></div><div class="card"><span>Lançamentos</span><b>${d.length}</b></div></div>${table(d.map(x => `<tr><td>${esc(x.ordens_servico?.numero)}</td><td>${esc(x.ordens_servico?.clientes?.nome)}</td><td>${esc(x.forma_pagamento)}</td><td>${money(x.valor)}</td><td>${dt(x.data_pagamento)}</td></tr>`), ['OS', 'Cliente', 'Forma', 'Valor', 'Data'], 'Nenhum recebimento.')}`
}

export async function servicos(c) {
  const d = must(await sb.from('servicos').select('*').order('nome'))
  c.innerHTML = `<div class="toolbar"><button class="primary" id="add">+ Novo serviço</button></div>${table(d.map(x => `<tr><td><b>${esc(x.nome)}</b><small>${esc(x.descricao)}</small></td><td>${money(x.valor_padrao)}</td><td><span class="badge">${x.ativo ? 'Ativo' : 'Inativo'}</span></td><td><button class="link" data-id="${esc(x.id)}">Editar</button></td></tr>`), ['Serviço', 'Valor padrão', 'Status', ''], 'Nenhum serviço.')}`
  $('#add', c).addEventListener('click', () => svcForm()); $$('[data-id]', c).forEach(b => b.addEventListener('click', () => svcForm(d.find(x => x.id === b.dataset.id))))
}
function svcForm(x = {}) {
  view(`<div class="panel form"><h3>${x.id ? 'Editar' : 'Novo'} serviço</h3><div class="grid2"><label>Nome*<input id="nome" value="${esc(x.nome)}"></label><label>Valor padrão<input id="valor_padrao" type="number" step="0.01" min="0" value="${esc(x.valor_padrao ?? 0)}"></label><label class="wide">Descrição<textarea id="descricao">${esc(x.descricao)}</textarea></label><label>Status<select id="ativo"><option value="1" ${x.ativo !== false ? 'selected' : ''}>Ativo</option><option value="0" ${x.ativo === false ? 'selected' : ''}>Inativo</option></select></label></div>
  <div class="actions"><button class="secondary" id="cancel">Cancelar</button><button class="primary" id="save">Salvar</button></div></div>`)
  $('#cancel').addEventListener('click', () => go('servicos'))
  $('#save').addEventListener('click', e => { if (!val('nome')) return toast('Informe o nome.', 1); busy(e.target, async () => { const p = { nome: val('nome'), descricao: val('descricao'), valor_padrao: +val('valor_padrao') || 0, ativo: val('ativo') === '1' }; must(x.id ? await sb.from('servicos').update(p).eq('id', x.id) : await sb.from('servicos').insert(p)); toast('Serviço salvo.'); go('servicos') }) })
}

export async function usuarios(c) {
  if (!/admin/i.test(state.me?.perfil?.nome || '')) { c.innerHTML = '<div class="error">Acesso restrito a administradores.</div>'; return }
  const d = must(await sb.from('usuarios').select('id,nome,telefone,ativo,perfis(nome)').order('nome'))
  c.innerHTML = `<div class="notice">Crie o usuário em <b>Supabase → Authentication → Users</b> e depois associe-o ao perfil na tabela <code>usuarios</code>.</div>${table(d.map(x => `<tr><td><b>${esc(x.nome)}</b></td><td>${esc(x.telefone)}</td><td>${esc(Array.isArray(x.perfis) ? x.perfis[0]?.nome : x.perfis?.nome)}</td><td><span class="badge">${x.ativo ? 'Ativo' : 'Inativo'}</span></td></tr>`), ['Usuário', 'Telefone', 'Perfil', 'Status'])}`
}
